package main.java.model;
import java.util.Date;

public class Appointment {
	private String appointmentId;
	private Date date;
	private String description;
	
	// getters function to get date and description.
	public void setAppointmentDate(Date date) {
		this.date = date;
	}
	public void setAppointmentDescription(String description) {
		this.description = description;
	}
	
	//setters  for id, date, and description
	public String getAppointmentId() {
		return appointmentId;
	}
	public Date getAppointmentDate() {
		return date;
	}
	public String getAppointmentDescription() {
		return description;
	}
	
	// throw  methods to make sure requirments are met
	private void verifyIdRequirements(String appointmentId) {
		if (appointmentId == null || appointmentId.length() > 10) {
			throw new IllegalArgumentException("Id not valid");
		}
		
	}
	
	private void verifyDateRequirements(Date date) {
		if (date == null || date.before(new Date())) {
			throw new IllegalArgumentException("Date not valid");
		}
	}
	
	private void verifyDescriptionRequirements(String description) {
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Description not valid");
		}

	}
	
	// object constructor
	public Appointment(String appointmentId, Date date, String description) {
		// run checks
		verifyIdRequirements(appointmentId);
		verifyDateRequirements(date);
		verifyDescriptionRequirements(description);
		

		this.appointmentId = appointmentId;
		this.date = date;
		this.description = description;
	}
	
}
