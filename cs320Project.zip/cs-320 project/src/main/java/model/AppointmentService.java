package main.java.model;
import java.util.ArrayList;
import java.util.List;

public class AppointmentService {
	// Creating an array to store appointments
	private static List<Appointment> appointments = new ArrayList<Appointment>();
	
	// Creating an array to store ids
	public static List<String> idList = new ArrayList<String>();
	
	// adding an appointment. Checking the id
	public static void addAppointment(Object appointment) {
		appointments.add((Appointment) appointment);
		for (int i = 0; i < idList.size(); i++) {
			if (((Appointment) appointment).getAppointmentId().equals(idList.get(i))) {
				throw new IllegalArgumentException("Id is taken");
			}
		}
		// if new id add it to list
		idList.add(((Appointment) appointment).getAppointmentId());
	}
	//checking if appointment exists
	public static boolean appointmentExists(String appointmentId) {
		for (int i = 0; i < appointments.size(); i++) {
			if (appointments.get(i).getAppointmentId().equals(appointmentId)) {
				return true;
			}
		}
		return false;
	}

	// delete appointment
	public static void deleteAppointment(String appointmentId) {
		for (int i = 0; i < appointments.size(); i++) {
			if (appointments.get(i).getAppointmentId().equals(appointmentId)) {
				appointments.remove(i);
			}
		}
	}

}
