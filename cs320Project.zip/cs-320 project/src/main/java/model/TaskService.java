package main.java.model;
import java.util.ArrayList;
import java.util.List;

public class TaskService {
	private static List<Task> tasks = new ArrayList<Task>();
	
	// Creating an array to store ids
	public static List<String> idList = new ArrayList<String>();
	
	// adding a task and making sure the id is unique.
	public static void addTask(Object task) {
		tasks.add((Task) task);	
		for (int i = 0; i < idList.size(); i++) {
			if (((Task) task).getTaskId().equals(idList.get(i))) {
				throw new IllegalArgumentException("Id in use");
			}
		}
		// if id is unique adding it to the array
		idList.add(((Task) task).getTaskId());
	}
	
	// go through list to see if task is already present
	public static boolean taskPresent(String taskId) {
		for (int i = 0; i < tasks.size(); i++) {
			if (tasks.get(i).getTaskId().equals(taskId)) {
				return true;
			}
		}
		return false;
	}
	
	
	// Going though the array, finding task, and updating it
	public static void updateTask(String taskId, String taskName, String taskDescription) {
		for (int i = 0; i < tasks.size(); i++) {
			if (tasks.get(i).getTaskId().equals(taskId)) {
				tasks.get(i).setTaskName(taskName);
				tasks.get(i).setTaskDescription(taskDescription);
			}
		}
	}
	
	// Going through array, finding task, and deleting task
	public static void deleteTask(String taskId) {
		for (int i = 0; i < tasks.size(); i++) {
			if (tasks.get(i).getTaskId().equals(taskId)) {
				tasks.remove(i);
			}
		}
	}
}
