package main.java.model;

public class Task {
	private String taskId;
	private String taskName;
	private String taskDescription;
	
	/* getters to retrieve data for taskid
	name and task description */
	public String getTaskId() {
		return this.taskId;
	}
	
	public String getTaskName() {
		return this.taskName;
	}
	
	public String getTaskDescription() {
		return this.taskDescription;
	}
	
	/* setters for name and description. ID should not be updated*/
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	
	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}
	
	// throw methods to for errors
	private void verifyIdRequirements(String taskId) {
		if (taskId == null || taskId.length() > 10 ) {
			throw new IllegalArgumentException("ID not valid!");
		}
	}
	
	private void verifyNameRequirements(String taskName) {
		if (taskName == null || taskName.length() > 20) {
			throw new IllegalArgumentException("Name not valid!");
		}
	}
	
	private void verifyDescriptionRequirements(String taskDescription) {
		if (taskDescription == null || taskDescription.length() > 50) {
			throw new IllegalArgumentException("Description not valid!");
		}
	
	}

	// object constructor for Task
	public Task(String taskId, String taskName, String taskDescription) {
		verifyIdRequirements(taskId);
		verifyNameRequirements(taskName);
		verifyDescriptionRequirements(taskDescription);
		
		this.taskId = taskId;
		this.taskName = taskName;
		this.taskDescription = taskDescription;
	}
}
