package test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import main.java.model.Task;

public class TaskTest {
	// test for original contact creation

	@Test 
	void testTask() {
		Task task = new Task("1234", "Study", "Study for the big math exam");
		Assertions.assertTrue(task.getTaskId().equals("1234"));
		Assertions.assertTrue(task.getTaskName().equals("Study"));
		Assertions.assertTrue(task.getTaskDescription().equals("Study for the big math exam"));
	}
	
	// test for Id too long
	@Test
	void testIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("1111111111111", "Study", "Study for the big math exam");
		});
	}
	//test for name too long
	@Test
	void testNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("1234", "Study for the biggest exam of your life", "Study for the big math exam");
		});
	}
	//test for description too long
	
	@Test
	void testDescriptionTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("1234", "Study", "I have to study for the biggest math exam in my life, and I hate math I hope I do not fail and have to retake the class.");
		});
	}
}
	
	