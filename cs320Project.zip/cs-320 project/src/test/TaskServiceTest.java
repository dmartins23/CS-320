package test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import main.java.model.Task;
import main.java.model.TaskService;

public class TaskServiceTest {
	@Test
	public void testUniqueId() {
		//creating a new tack and adding it to the tasks.
		Task newTask = new Task("10", "Study", "Study for chemistry");
		TaskService.addTask(newTask);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			// using the same id to add a task.
			Task newerTask = new Task("10", "Gym", "Go to the gym for an hour");
			TaskService.addTask(newerTask);
		});
	}
	
	@Test
	public void testAddTask() {
		// test for adding a new task
		Task newTask = new Task("11", "walk", "Walk outside for 30 mins");
		TaskService.addTask(newTask);
		Assertions.assertTrue(TaskService.taskPresent("11")); 
	}
	
	@Test
	public void testDeleteTask() {
		// test for deleting a new task
		Task newTask = new Task("12", "clean", "do the dishes");
		TaskService.addTask(newTask);
		TaskService.deleteTask("12");
		Assertions.assertFalse(TaskService.taskPresent("12"));
	}
	
	@Test
	public void testUpdateTask() {
		// test for updating a new task.
		Task newTask = new Task("13", "mop", "mop the floor");
		TaskService.addTask(newTask);
		TaskService.updateTask("13", "babysit", "watch the kids after school");
		
	}
	
}
