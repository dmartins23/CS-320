package test;

import static org.junit.jupiter.api.Assertions.*;

import main.java.model.Contact;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


class ContactTest {
	
	// test for original contact creation
	@Test
	void testContact() {
		Contact newContact = new Contact("1001", "Dave", "Martins", "2037291111", 
				"100 Main st. Nauagatuck, CT");
		assertTrue(newContact.getFirstName().equals("Dave"));
		assertTrue(newContact.getLastName().equals("Martins"));
		assertTrue(newContact.getId().equals("1001"));
		assertTrue(newContact.getPhone().equals("2037291111"));
		assertTrue(newContact.getAddress().equals("100 Main st. Nauagatuck, CT"));
	}
	// test for Id is too long
	@Test
	void testContactClassIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("10000000000", "Dave", "Martins", "2037291111", 
				"100 Main st. Nauagatuck, CT");
		});
	}
	// test for too long first name
	@Test
	void testContactClassFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("10001", "Dave1234567", "Martins", "2037291111", 
					"100 Main st. Nauagatuck, CT");
		});
	}

	// test for too long last name
	@Test
	void testContactClassLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("10001", "Dave", "Martins123456", "2037291111", 
					"100 Main st. Nauagatuck, CT");
		});
	}
	
	// test for not exactly 10 characters
	@Test
	void testContactClassPhoneNot10() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("10001", "Dave", "Martins", "20372911111", 
					"100 Main st. Nauagatuck, CT");
		});
	}
	
	// test for too long address
	@Test
	void testContactClassAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("10001", "Dave", "Martins", "2037291111", 
					"100 Main st. Nauagatuck, CTdlkdklkdldkkdlkdk");
		});
	}
	}