package test;

import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.Assertions;
import java.util.Date;
import main.java.model.Appointment;
import main.java.model.AppointmentService;

public class AppointmentServiceTest {
	@Test
	public void testUniqueId() {
		// creating a date in the future
		@SuppressWarnings("deprecation")
		Date date = new Date(2021, 5, 17, 23, 30, 56); 
		// creating and adding a new appointment
		Appointment newAppointment = new Appointment("1", date, "Appointment");
		AppointmentService.addAppointment(newAppointment);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			//adding a new appointment with same id
			Appointment newerAppointment = new Appointment("1", date, "Appointment id in use");
			AppointmentService.addAppointment(newerAppointment);
		});
	}
	
	@Test
	public void testAddAppointment() {
		// future date
		@SuppressWarnings("deprecation")
		Date date = new Date(2021, 5, 17, 23, 30, 56); 
		// create and add a appointment and verifying it
		Appointment newAppointment = new Appointment("2", date, "Appointment 2");
		AppointmentService.addAppointment(newAppointment);
		Assertions.assertTrue(AppointmentService.appointmentExists("2")); 
	}
	
	@Test
	public void testDeleteAppointment() {
		// create date in the future
		@SuppressWarnings("deprecation")
		Date date = new Date(2021, 5, 17, 23, 30, 56); 
		//delete an appointment
		Appointment newAppointment = new Appointment("3", date, "Appointment removed");
		AppointmentService.addAppointment(newAppointment);
		AppointmentService.deleteAppointment("3");
		Assertions.assertFalse(AppointmentService.appointmentExists("3"));
	}

	
}