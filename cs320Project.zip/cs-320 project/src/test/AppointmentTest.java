package test;

import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import main.java.model.Appointment;
import main.java.model.AppointmentService;

class AppointmentTest { 
	//test for id too long
	@Test
	void testIdTooLong() {
		Date date = new Date();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("77686676876766", date, "doctor appt");
		});
	}
	//test for valid date
	@Test
	void testDateInPast() throws InterruptedException {
		Date date = new Date();
        Thread.sleep(1000);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("1133557799", date, "doctor appt");
		});
	}
	
	
	@Test
	void testDescriptionTooLong() {
		Date date = new Date();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("1133557799", date, "doctor appt is coming up and I dont know if I can make it. I may need to change the date");
		});
	}

}
