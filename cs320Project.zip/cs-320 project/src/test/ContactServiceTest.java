package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import main.java.model.Contact;
import main.java.model.ContactService;

class ContactServiceTest {

	//create a contact and test values
	@Test
	void testContactServiceClass() {
		ContactService.addContact("Dave", "Martins", "2037291111", 
				"100 Main st. Nauagatuck, CT");
		assertTrue(ContactService.contactList.get(0).getId().equals("1000000002"));
		assertTrue(ContactService.contactList.get(0).getFirstName().equals("Dave"));
		assertTrue(ContactService.contactList.get(0).getLastName().equals("Martins"));
		assertTrue(ContactService.contactList.get(0).getPhone().equals("2037291111"));
		assertTrue(ContactService.contactList.get(0).getAddress().equals("100 Main st. Nauagatuck, CT"));
	}
	// deletion of a contact
	@Test
	void testContactServiceDelete() {
		ContactService.addContact("Dave", "Martins", "2037291111", 
				"100 Main st. Nauagatuck, CT");
		int size = ContactService.contactList.size();
		ContactService.deleteContact("1000000003");
		assertTrue(ContactService.searchContact("1000000003") == 2);
	}
	// update first name test
	@Test
	void testContactServiceUpdateFirstName() {
		ContactService.addContact("Jack", "Smith", "2037292222", "200 Main st. Nauagatuck, CT");
		int size = ContactService.contactList.size();
		ContactService.updateFirstName("1000000003", "Mary");
		assertTrue(ContactService.contactList.get(size - 1).getFirstName().equals("Mary"));
	}
	// test confirming update to last name
	@Test
	void testContactServiceUpdateLastName() {
		int size = ContactService.contactList.size();
		ContactService.updateLastName("1000000003", "Smith");
		assertTrue(ContactService.contactList.get(size - 1).getLastName().equals("Smith"));
	}
	// test for updated phone number
	@Test
	void testContactServiceUpdatePhone() {
		int target = 0;
		target = ContactService.findIndex("1000000003");
		ContactService.updatePhoneNum("1000000003", "2037293333");
		assertTrue(ContactService.contactList.get(target).getPhone().equals("2037293333"));
	}
	// test for updated address
	@Test
	void testContactServiceUpdateAddress() {
		int target = 0;
		target = ContactService.findIndex("1000000003");
		ContactService.updateAddress("1000000003", "300 Main st. Nauagatuck, CT");
		assertTrue(ContactService.contactList.get(target).getAddress().equals("300 Main st. Nauagatuck, CT"));
	}
	
	// test for unique ID
	@Test
	void testContactServiceUniqueId() {
		Contact newContact = new Contact("12345", "Jerry", "Smith", "2037294444", "Original Contact Address");
		ContactService.addContact(newContact);
		Contact duplicateId = new Contact("12345", "Jerry", "Smith", "2037294444", "Duplicate Contact Address");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			ContactService.addContact(duplicateId);
		});
	}

}